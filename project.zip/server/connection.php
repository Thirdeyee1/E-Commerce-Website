    <?php

    $conn=mysqli_connect("localhost","thirdex","example-password","new_schema");
    if(!$conn)
    die("couldn't connect".mysqli_connect_error());
 

    



    ?>